# ChurnGuard — Customer Churn Prediction & Retention Analytics Platform

**ChurnGuard** is a full-stack customer churn intelligence application built with **Python**, **Flask**, **SQLite**, and **scikit-learn**. It empowers customer success and retention teams to identify accounts at risk of leaving, diagnose the primary driving factors via model interpretability decomposition, receive prescriptive retention playbooks, and monitor cohort health over time on an executive dashboard.

---

## 1. System Requirements & Prerequisites

- **Operating System:** Windows 10/11, macOS, or Linux.
- **Python Version:** Python **3.10** or higher (tested on 3.10 and 3.11).
- **Terminal:** Windows PowerShell (or Command Prompt / bash).
- **Web Browser:** Any modern browser (Chrome, Edge, Firefox, Safari).

---

## 2. Installation & Quick Start (Windows PowerShell)

Follow these step-by-step commands in **Windows PowerShell**:

### Step 1: Open the Project Directory
```powershell
cd churnguard
```

### Step 2: Create and Activate Virtual Environment
```powershell
# Create the virtual environment
py -m venv .venv

# Activate the virtual environment
.\.venv\Scripts\Activate.ps1
```

> **Note for PowerShell execution policy:**  
> If PowerShell displays a script execution policy restriction error (`cannot be loaded because running scripts is disabled`), run:
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> .\.venv\Scripts\Activate.ps1
> ```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Database Initialization & ML Model Setup
- **Automatic Initialization:** You do **not** need to manually create the SQLite database or train the model. On first boot, ChurnGuard creates `instance/churnguard.db`, runs versioned database migrations (`PRAGMA user_version`), and trains the scikit-learn model automatically.
- **Manual Retraining (Optional):** If you wish to pre-train or retrain the model explicitly:
  ```powershell
  python train_model.py
  ```
- **Seed Benchmark Demo Data (Optional):** To populate the dashboard with 60 realistic customer assessment records for demonstration:
  ```powershell
  python seed_demo.py 60
  ```
  *(To remove demo records at any time: `python seed_demo.py --clear`)*

### Step 5: Start the Flask Application
```powershell
python app.py
```

### Step 6: Access the Web Application
Open your web browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 3. Demo Mode & Authentication

ChurnGuard includes a configurable **Demo Authentication** system designed for seamless presentations and testing:
- **Sign In:** Any standard email format (e.g. `analyst@company.com` or `sourav.analyst@churnguard.local`) and any non-empty password grants access.
- **Security Transparency:** In demo mode, passwords are not stored, validated against external identity providers, or compared. Sessions are cryptographically signed using a unique secret key generated once and stored in `instance/secret_key`.
- **Pre-filled Credentials:** The login page provides an *"Auto-fill Demo Credentials"* button for one-click testing.

---

## 4. Demonstration Delay (`DEMO_DELAY_SECONDS`)

To simulate enterprise AI processing workflows during live pitches and demos, ChurnGuard includes a configurable delay feature:
- **Default Delay:** 20 seconds (`DEMO_DELAY_SECONDS=20`).
- **How It Operates:** The scikit-learn inference pipeline and SQLite write complete **immediately** on the server. The result view is paced with an animated audit progress indicator (`processing.html`) showing validation, scaling, prediction, and playbook generation stages.
- **Configurability:** Users can adjust or disable the delay (0 to 60 seconds) in **Settings**. Setting it to `0` provides instant results.
- **Production Safety:** In production mode (`CHURNGUARD_ENV=production`), this artificial delay is permanently locked to 0.

---

## 5. Configuration & Environment Variables

All settings have sensible defaults, but can be customized in PowerShell (`$env:NAME="value"`) or via `.env`:

| Variable | Default | Description |
|---|---|---|
| `CHURNGUARD_ENV` | `development` | Set to `production` to disable demo delays and enforce HTTPS `Secure` cookies. |
| `SECRET_KEY` | Auto-generated | Flask session encryption key. Stored in `instance/secret_key` if unset. |
| `DEMO_DELAY_SECONDS` | `20` | Default demo delay in seconds for new sessions. |
| `GITHUB_REPO_URL` | `""` (empty) | Your public GitHub repository URL (e.g. `https://github.com/souravvvv18/churnguard`). Also editable in Settings. |
| `GITHUB_PROFILE_URL` | `https://github.com/souravvvv18` | Contributor and author GitHub profile link. |
| `PORT` | `5000` | Port for the Flask HTTP server. |
| `HOST` | `127.0.0.1` | Network interface binding host. |

---

## 6. Testing & Automated Verification

Run the full automated test suite using `pytest` or Python's built-in `unittest`:

```powershell
# Run with pytest (recommended)
pytest tests/test_app.py -v

# Or run with unittest
python -m unittest tests/test_app.py -v
```

The test suite covers:
- Authentication, session cookies (`HttpOnly`, `SameSite=Lax`), CSRF tokens, and open-redirect prevention.
- Protected routes redirecting unauthenticated users.
- Form input validation (out-of-range, missing, and non-numeric inputs rejected with 422).
- Real scikit-learn model inference verification against expected probability bounds.
- SQLite persistence across app reboots and versioned migrations.
- Duplicate submission deduplication (preventing duplicate writes on rapid refresh).
- Demo delay pacing and status polling (`/api/records/<pid>/status`).
- Dynamic theme persistence in SQLite and cookies (`/api/theme`).
- Feature request & feedback validation, SQLite storage (`feedback` table), and public listing.
- Corrupted model recovery and missing model handling.

---

## 7. Machine Learning Architecture & Limitations

### Pipeline Structure
- **Preprocessing:** `ColumnTransformer` combines `StandardScaler` for continuous numeric columns (`tenure`, `monthly_charges`, `total_charges`, `num_services`, `support_tickets`, `satisfaction`) and `OneHotEncoder(handle_unknown="ignore")` for categorical features (`contract`, `payment_method`, `internet_service`, `paperless_billing`).
- **Classifier:** `LogisticRegression(max_iter=1000)` calibrated for probabilistic outputs via sigmoid activation.
- **Explainability:** Feature contribution weights are extracted by multiplying the linear model coefficients by the normalized feature vectors (`clf.coef_[0] * pre.transform(X)[0]`).
- **Risk Tiers:** 
  - **Low Risk:** Probability < 30%
  - **Medium Risk:** Probability 30% – 60%
  - **High Risk:** Probability &ge; 60%

### Known Limitations & Real Data Integration
- **Synthetic Training Data:** The model included in demonstration mode is trained on a synthetic dataset generated via `ml.synth()`. While it mimics real-world telecom churn patterns (e.g., month-to-month contracts and high support tickets strongly correlate with attrition), it is **not validated for critical production decisions**.
- **Connecting Real Data:** To train on your company's historical telemetry, replace the `synth()` generator in `train_model.py` with a pandas DataFrame containing the columns specified in `ml.FEATURES` plus a binary `0/1` churn label, then run `python train_model.py`.

---

## 8. Transitioning to Production Mode

Before deploying ChurnGuard into a live enterprise production environment:
1. Set `$env:CHURNGUARD_ENV="production"` (enables `Secure` cookies and disables debug mode).
2. Set a strong random `$env:SECRET_KEY="<cryptographically_secure_random_key>"`.
3. Replace demo authentication in `auth.py` with an enterprise identity provider (e.g. OAuth 2.0 / SAML / Firebase Auth or bcrypt/Argon2 password hashing).
4. Serve the application behind a production WSGI server such as **Gunicorn** or **Waitress** (on Windows):
   ```powershell
   pip install waitress
   waitress-serve --port=5000 app:create_app
   ```

---

## 9. Contributors & Author

- **Sourav** — Project Author & Full-Stack Engineer ([GitHub Profile](https://github.com/souravvvv18))
