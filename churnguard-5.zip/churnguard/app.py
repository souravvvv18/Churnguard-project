import os, secrets
from pathlib import Path
from flask import Flask, render_template
import auth, db as store, views
from config import Config


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    inst = Path(app.config["DATABASE"]).parent
    inst.mkdir(parents=True, exist_ok=True)
    key_file = inst / "secret_key"  # generated once, kept out of git
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or (
            key_file.read_text().strip() if key_file.exists() else _new_key(key_file))
    store.init_app(app)
    auth.init_app(app)
    app.register_blueprint(views.bp)

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(500)
    def error(e):
        code = getattr(e, "code", 500)
        msg = {404: "That page or record does not exist.", 400: getattr(e, "description", "Bad request.")}.get(code, "Something went wrong on our side.")
        return render_template("error.html", code=code, message=msg), code
    return app


def _new_key(path):
    k = secrets.token_hex(32)
    path.write_text(k)
    return k


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    host = os.getenv("HOST", "127.0.0.1")
    create_app().run(host=host, port=port, debug=not Config.PRODUCTION)

