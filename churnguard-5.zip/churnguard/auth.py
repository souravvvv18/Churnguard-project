"""Demo authentication + CSRF. Replace verify_password() with a real check (e.g. hashed passwords) later."""
import re, secrets
from functools import wraps
from flask import abort, redirect, request, session, url_for

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")


def verify_password(email, password):
    # DEMO ONLY: any non-empty password is accepted. Nothing is stored or compared.
    return bool(password)


def check_credentials(email, password):
    if not email or len(email) > 254 or not EMAIL_RE.match(email):
        return "Enter a valid email address."
    if not password:
        return "Password cannot be empty."
    if len(password) > 256 or not verify_password(email, password):
        return "Invalid credentials."
    return None


def login_user(email):
    session.clear()  # prevents session fixation
    session.permanent = True
    session["user"] = email


def current_user():
    return session.get("user")


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for("main.login", next=request.full_path.rstrip("?")))
        return fn(*a, **kw)
    return wrapper


def safe_next(url):
    return bool(url) and url.startswith("/") and not url.startswith("//") and "\\" not in url


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def init_app(app):
    @app.before_request
    def _csrf():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
            known = session.get("csrf", "")
            if not sent or not known or not secrets.compare_digest(sent.encode(), known.encode()):
                abort(400, "Invalid or missing CSRF token. Reload the page and try again.")
