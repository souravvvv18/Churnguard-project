import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
INSTANCE = BASE / "instance"
PRODUCTION = os.getenv("CHURNGUARD_ENV", "development").lower() == "production"
PROFILE = os.getenv("GITHUB_PROFILE_URL", "https://github.com/souravvvv18")


class Config:
    VERSION = "2.0.0"
    PRODUCTION = PRODUCTION
    DATABASE = str(INSTANCE / "churnguard.db")
    MODEL_PATH = str(INSTANCE / "model.joblib")
    META_PATH = str(INSTANCE / "model_meta.json")
    AUTO_TRAIN = True                      # train automatically if model file is missing
    DEMO_DELAY_SECONDS = int(os.getenv("DEMO_DELAY_SECONDS", "20"))  # ignored (0) in production
    GITHUB_PROFILE_URL = PROFILE
    GITHUB_REPO_URL = os.getenv("GITHUB_REPO_URL", "")  # not provided yet; set via env or Settings
    PAGE_SIZE = 15
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = PRODUCTION
    PERMANENT_SESSION_LIFETIME = 8 * 3600
    MAX_CONTENT_LENGTH = 64 * 1024
    CONTRIBUTORS = [{"name": "Sourav", "role": "Project author", "url": PROFILE}]
