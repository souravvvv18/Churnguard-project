"""SQLite access layer with versioned migrations (PRAGMA user_version)."""
import hashlib, json, os, secrets, sqlite3
from datetime import datetime, timedelta
from flask import current_app, g
import ml

FMT = "%Y-%m-%d %H:%M:%S"
now = lambda: datetime.now().strftime(FMT)

SCHEMA = """
CREATE TABLE IF NOT EXISTS predictions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  user_email TEXT, company TEXT NOT NULL, customer_ref TEXT,
  tenure INTEGER, monthly_charges REAL, total_charges REAL, num_services INTEGER,
  support_tickets INTEGER, satisfaction INTEGER, contract TEXT, paperless_billing TEXT,
  payment_method TEXT, internet_service TEXT,
  probability REAL NOT NULL, risk TEXT NOT NULL, factors TEXT, actions TEXT,
  input_hash TEXT, is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, released_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_pred_created ON predictions(created_at);
CREATE INDEX IF NOT EXISTS ix_pred_company ON predictions(company);
CREATE TABLE IF NOT EXISTS preferences(user_email TEXT NOT NULL, key TEXT NOT NULL, value TEXT, PRIMARY KEY(user_email, key));
CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT);
"""
OLD_SAMPLES = {"Amit", "Neha", "Rahul", "Priya", "Karan", "Sneha", "Vikram", "Anjali"}


def _m1(c):
    cols = [r[1] for r in c.execute("PRAGMA table_info(predictions)")]
    legacy = bool(cols) and "public_id" not in cols
    if legacy:  # v1 prototype table: keep its rows
        c.execute("ALTER TABLE predictions RENAME TO predictions_legacy")
    c.executescript(SCHEMA)
    if legacy:
        for r in c.execute("SELECT * FROM predictions_legacy").fetchall():
            when = (r["created"] or now()) + ":00" if len(r["created"] or "") == 16 else (r["created"] or now())
            c.execute("""INSERT INTO predictions(public_id,company,customer_ref,tenure,monthly_charges,support_tickets,
                contract,probability,risk,factors,actions,is_demo,created_at,released_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (f"CG-L{r['id']:05d}", "Legacy import (v1)", r["name"], r["tenure"], r["monthly"], r["calls"],
                       ml.CHOICES["contract"][r["contract"]], r["prob"], ml.risk_level(r["prob"]),
                       json.dumps([{"label": r["reason"], "weight": 0}]), "[]",
                       int(r["name"] in OLD_SAMPLES), when, when))


def _m2(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS feedback(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      public_id TEXT NOT NULL UNIQUE,
      user_email TEXT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_feedback_created ON feedback(created_at);
    """)


MIGRATIONS = [_m1, _m2]



def connect(path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    c = sqlite3.connect(path)
    c.row_factory = sqlite3.Row
    return c


def migrate(path):
    c = connect(path)
    v = c.execute("PRAGMA user_version").fetchone()[0]
    for i, fn in enumerate(MIGRATIONS, 1):
        if i > v:
            fn(c)
            c.execute(f"PRAGMA user_version={i}")
    c.commit()
    c.close()


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def init_app(app):
    migrate(app.config["DATABASE"])
    app.teardown_appcontext(close_db)


def close_db(e=None):
    d = g.pop("db", None)
    if d:
        d.close()


# ---------- predictions ----------
def insert_prediction(c, rec, delay=0, demo=False):
    """Returns (public_id, duplicate). Identical submission by same user within 60s returns the existing record."""
    key = json.dumps([rec["company"], rec["customer_ref"]] + [rec[k] for k in ml.FEATURES], sort_keys=True)
    h = hashlib.sha256(key.encode()).hexdigest()
    cutoff = (datetime.now() - timedelta(seconds=60)).strftime(FMT)
    row = c.execute("SELECT public_id FROM predictions WHERE input_hash=? AND user_email IS ? AND created_at>=? AND is_demo=?",
                    (h, rec.get("user_email"), cutoff, int(demo))).fetchone()
    if row:
        return row["public_id"], True
    created = rec.get("created_at") or now()
    released = (datetime.strptime(created, FMT) + timedelta(seconds=delay)).strftime(FMT)
    for _ in range(5):
        pid = "CG-" + secrets.token_hex(4).upper()
        try:
            c.execute("""INSERT INTO predictions(public_id,user_email,company,customer_ref,tenure,monthly_charges,total_charges,
              num_services,support_tickets,satisfaction,contract,paperless_billing,payment_method,internet_service,
              probability,risk,factors,actions,input_hash,is_demo,created_at,released_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (pid, rec.get("user_email"), rec["company"], rec["customer_ref"], rec["tenure"], rec["monthly_charges"],
                       rec["total_charges"], rec["num_services"], rec["support_tickets"], rec["satisfaction"], rec["contract"],
                       rec["paperless_billing"], rec["payment_method"], rec["internet_service"], rec["probability"], rec["risk"],
                       json.dumps(rec["factors"]), json.dumps(rec["actions"]), h, int(demo), created, released))
            c.commit()
            return pid, False
        except sqlite3.IntegrityError:
            c.rollback()
    raise sqlite3.Error("Could not allocate a unique record id")


def _row(r):
    d = dict(r)
    d["factors"] = json.loads(d["factors"] or "[]")
    d["actions"] = json.loads(d["actions"] or "[]")
    return d


def get_prediction(c, pid):
    r = c.execute("SELECT * FROM predictions WHERE public_id=?", (pid,)).fetchone()
    return _row(r) if r else None


def seconds_until(ts):
    return max(0.0, (datetime.strptime(ts, FMT) - datetime.now()).total_seconds())


SORTS = {"created_at", "company", "probability", "tenure", "monthly_charges", "risk"}


def where(f):
    w, a = ["released_at <= ?"], [now()]
    if f.get("q"):
        w.append("(company LIKE ? OR customer_ref LIKE ? OR public_id LIKE ?)")
        a += [f"%{f['q']}%"] * 3
    for k in ("company", "risk", "contract"):
        if f.get(k):
            w.append(f"{k} = ?")
            a.append(f[k])
    if f.get("source") in ("real", "demo"):
        w.append("is_demo = ?")
        a.append(1 if f["source"] == "demo" else 0)
    if f.get("date_from"):
        w.append("date(created_at) >= ?")
        a.append(f["date_from"])
    if f.get("date_to"):
        w.append("date(created_at) <= ?")
        a.append(f["date_to"])
    return " AND ".join(w), a


def list_predictions(c, f, sort="created_at", direction="desc", page=1, size=15):
    sort = sort if sort in SORTS else "created_at"
    direction = "ASC" if direction == "asc" else "DESC"
    w, a = where(f)
    total = c.execute(f"SELECT COUNT(*) FROM predictions WHERE {w}", a).fetchone()[0]
    q = f"SELECT * FROM predictions WHERE {w} ORDER BY {sort} {direction}, id DESC"
    if size:
        q += " LIMIT ? OFFSET ?"
        a = a + [size, (page - 1) * size]
    return [_row(r) for r in c.execute(q, a).fetchall()], total


def companies(c):
    return [r[0] for r in c.execute("SELECT DISTINCT company FROM predictions ORDER BY company")]


def stats(c, f):
    w, a = where(f)
    one = lambda q: c.execute(q.format(w=w), a).fetchone()[0]
    records = one("SELECT COUNT(*) FROM predictions WHERE {w}")
    s = {"records": records, "customers": one("SELECT COUNT(DISTINCT company||'|'||customer_ref) FROM predictions WHERE {w} AND customer_ref IS NOT NULL AND customer_ref<>''"),
         "no_id_records": one("SELECT COUNT(*) FROM predictions WHERE {w} AND (customer_ref IS NULL OR customer_ref='')"),
         "companies": one("SELECT COUNT(DISTINCT company) FROM predictions WHERE {w}")}
    risk = {r["risk"]: r["n"] for r in c.execute(f"SELECT risk, COUNT(*) n FROM predictions WHERE {w} GROUP BY risk", a)}
    s["risk"] = [risk.get(k, 0) for k in ml.RISKS]
    s["high"] = risk.get("High", 0)
    s["high_pct"] = round(100 * s["high"] / records, 1) if records else 0
    s["avg_prob"] = round(100 * (one("SELECT AVG(probability) FROM predictions WHERE {w}") or 0), 1)
    bins = [0] * 10
    for (p,) in c.execute(f"SELECT probability FROM predictions WHERE {w}", a):
        bins[min(int(p * 10), 9)] += 1
    s["hist"] = {"labels": [f"{i*10}-{i*10+10}%" for i in range(10)], "counts": bins}
    t = c.execute(f"SELECT date(created_at) d, COUNT(*) n, AVG(probability) p, SUM(risk='High') h FROM predictions WHERE {w} GROUP BY d ORDER BY d", a).fetchall()
    s["trend"] = {"labels": [r["d"] for r in t], "count": [r["n"] for r in t],
                  "avg": [round(100 * r["p"], 1) for r in t], "high": [r["h"] for r in t]}
    bc = {}
    for r in c.execute(f"SELECT contract, risk, COUNT(*) n FROM predictions WHERE {w} GROUP BY contract, risk", a):
        bc.setdefault(r["contract"], {})[r["risk"]] = r["n"]
    s["by_contract"] = {"labels": list(bc), "series": {k: [bc[x].get(k, 0) for x in bc] for k in ml.RISKS}}
    s["high_list"] = [_row(r) for r in c.execute(
        f"SELECT * FROM predictions WHERE {w} AND risk='High' ORDER BY probability DESC LIMIT 8", a)]
    return s


# ---------- preferences / settings ----------
def get_prefs(c, email):
    return {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM preferences WHERE user_email=?", (email,))}


def set_pref(c, email, key, value):
    c.execute("INSERT INTO preferences VALUES(?,?,?) ON CONFLICT(user_email,key) DO UPDATE SET value=excluded.value", (email, key, value))
    c.commit()


def get_setting(c, key, default=""):
    r = c.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def set_setting(c, key, value):
    c.execute("INSERT INTO app_settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    c.commit()


# ---------- feedback / feature requests ----------
def insert_feedback(c, rec):
    created = rec.get("created_at") or now()
    for _ in range(5):
        fid = "FB-" + secrets.token_hex(4).upper()
        try:
            c.execute("""INSERT INTO feedback(public_id, user_email, title, category, description, status, created_at)
                         VALUES(?,?,?,?,?,?,?)""",
                      (fid, rec.get("user_email"), rec["title"], rec["category"], rec["description"],
                       rec.get("status", "open"), created))
            c.commit()
            return fid
        except sqlite3.IntegrityError:
            c.rollback()
    raise sqlite3.Error("Could not allocate a unique feedback id")


def list_feedback(c, limit=50):
    rows = c.execute("SELECT * FROM feedback ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]

