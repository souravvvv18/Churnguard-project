"""Model layer: schema, training, loading, prediction, explanation."""
import json, os, threading
from datetime import datetime
import joblib, numpy as np, pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUM = ["tenure", "monthly_charges", "total_charges", "num_services", "support_tickets", "satisfaction"]
CHOICES = {
    "contract": ["Month-to-month", "One year", "Two year"],
    "paperless_billing": ["Yes", "No"],
    "payment_method": ["Electronic check", "Mailed check", "Bank transfer", "Credit card"],
    "internet_service": ["Fiber optic", "DSL", "None"],
}
CAT = list(CHOICES)
FEATURES = NUM + CAT
RISKS = ["Low", "Medium", "High"]
LABELS = {"tenure": "Tenure (months)", "monthly_charges": "Monthly charges", "total_charges": "Total charges",
          "num_services": "Subscribed services", "support_tickets": "Support tickets", "satisfaction": "Satisfaction (1-5)"}


class ModelUnavailable(Exception):
    pass


def risk_level(p):  # business thresholds, not model-calibrated
    return "Low" if p < 0.30 else "Medium" if p < 0.60 else "High"


def synth(n, seed=42):
    """Synthetic training data. Replace with a real dataset for real use (see README)."""
    r = np.random.default_rng(seed)
    d = pd.DataFrame({
        "tenure": r.integers(0, 73, n),
        "contract": r.choice(CHOICES["contract"], n, p=[.55, .25, .20]),
        "internet_service": r.choice(CHOICES["internet_service"], n, p=[.40, .40, .20]),
        "paperless_billing": r.choice(["Yes", "No"], n, p=[.6, .4]),
        "payment_method": r.choice(CHOICES["payment_method"], n, p=[.35, .2, .2, .25]),
        "num_services": r.integers(1, 9, n),
        "support_tickets": np.clip(r.poisson(1.5, n), 0, 20),
        "satisfaction": r.choice([1, 2, 3, 4, 5], n, p=[.08, .12, .25, .35, .20]),
    })
    base = np.where(d.internet_service == "None", 20, np.where(d.internet_service == "DSL", 45, 70))
    d["monthly_charges"] = np.clip(base + 6 * d.num_services + r.normal(0, 8, n), 15, 200).round(2)
    d["total_charges"] = (d.tenure * d.monthly_charges * r.uniform(.9, 1.05, n)).round(2)
    z = (-0.9 - 0.035 * d.tenure + 0.015 * (d.monthly_charges - 70)
         + d.contract.map({"Month-to-month": 1.0, "One year": -0.2, "Two year": -1.0})
         + 0.3 * (d.paperless_billing == "Yes") + 0.6 * (d.payment_method == "Electronic check")
         + d.internet_service.map({"Fiber optic": 0.4, "DSL": 0.0, "None": -0.5})
         + 0.3 * d.support_tickets - 0.55 * (d.satisfaction - 3) - 0.1 * (d.num_services - 4))
    y = (r.random(n) < 1 / (1 + np.exp(-z))).astype(int)
    return d, y


def train(model_path, meta_path, n=6000, seed=42):
    X, y = synth(n, seed)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=seed, stratify=y)
    pre = ColumnTransformer([("num", StandardScaler(), NUM),
                             ("cat", OneHotEncoder(handle_unknown="ignore"), CAT)], sparse_threshold=0)
    model = Pipeline([("pre", pre), ("clf", LogisticRegression(max_iter=1000))]).fit(Xtr, ytr)
    pr = model.predict_proba(Xte)[:, 1]
    meta = {"trained_at": datetime.now().strftime("%Y-%m-%d %H:%M"), "data_source": "synthetic",
            "n_samples": n, "churn_rate": round(float(y.mean()), 3), "algorithm": "Logistic Regression",
            "holdout_roc_auc": round(float(roc_auc_score(yte, pr)), 3),
            "holdout_accuracy": round(float(accuracy_score(yte, pr >= .5)), 3),
            "holdout_brier": round(float(brier_score_loss(yte, pr)), 3), "sklearn": sklearn.__version__}
    os.makedirs(os.path.dirname(model_path) or ".", exist_ok=True)
    joblib.dump(model, model_path)
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    return model


_cache, _lock = {}, threading.Lock()


def get_model(model_path, meta_path, auto_train=True):
    with _lock:
        if not os.path.exists(model_path):
            if not auto_train:
                raise ModelUnavailable("Model file not found. Run: python train_model.py")
            try:
                train(model_path, meta_path)
            except Exception as e:
                raise ModelUnavailable(f"Model file missing and training failed: {e}")
        mt = os.path.getmtime(model_path)
        if model_path in _cache and _cache[model_path][0] == mt:
            return _cache[model_path][1]
        try:
            m = joblib.load(model_path)
            m.predict_proba(pd.DataFrame([{k: (1 if k in NUM else CHOICES[k][0]) for k in FEATURES}]))
        except Exception as e:
            raise ModelUnavailable(f"Model file could not be loaded ({type(e).__name__}). Re-run: python train_model.py")
        _cache[model_path] = (mt, m)
        return m


def read_meta(meta_path):
    try:
        with open(meta_path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _label(name, f):
    kind, rest = name.split("__", 1)
    if kind == "num":
        return f"{LABELS[rest]}: {f[rest]}"
    col = next(c for c in CAT if rest.startswith(c + "_"))
    return f"{col.replace('_', ' ').capitalize()}: {rest[len(col) + 1:]}"


def actions_for(f, risk):
    a = []
    if f["contract"] == "Month-to-month" and risk != "Low":
        a.append("Offer an incentive to move to a 12-month contract.")
    if f["payment_method"] == "Electronic check":
        a.append("Encourage automatic payment (card or bank transfer).")
    if f["support_tickets"] >= 3:
        a.append("Assign an account manager and close open support tickets.")
    if f["satisfaction"] <= 2:
        a.append("Schedule a satisfaction follow-up call.")
    if f["internet_service"] == "Fiber optic" and f["monthly_charges"] > 90 and risk != "Low":
        a.append("Review plan fit and pricing for this customer.")
    if f["num_services"] <= 2 and risk != "Low":
        a.append("Suggest a service bundle to increase product adoption.")
    if f["tenure"] < 12 and risk != "Low":
        a.append("Run an onboarding check-in during the first year.")
    return a or ["No specific risk driver found. Continue regular engagement."]


def predict(model, f):
    """Real model inference. Returns probability, risk level, factors and rule-based actions."""
    X = pd.DataFrame([{k: f[k] for k in FEATURES}])
    p = float(model.predict_proba(X)[0, 1])
    pre, clf = model.named_steps["pre"], model.named_steps["clf"]
    contrib = clf.coef_[0] * pre.transform(X)[0]
    names = pre.get_feature_names_out()
    factors = [{"label": _label(n, f), "weight": round(float(c), 3)}
               for n, c in zip(names, contrib) if abs(c) >= 0.02]
    factors.sort(key=lambda x: -abs(x["weight"]))
    risk = risk_level(p)
    return {"probability": p, "risk": risk, "factors": factors[:8], "actions": actions_for(f, risk)}
