"""Optional: add clearly-flagged DEMO records (scored by the real model) so an empty dashboard can be shown.
Usage: python seed_demo.py [count]   |   python seed_demo.py --clear"""
import sys
from datetime import datetime, timedelta
import numpy as np
from app import create_app
import db as store, ml


def main():
    app = create_app()
    c = store.connect(app.config["DATABASE"])
    if "--clear" in sys.argv:
        c.execute("DELETE FROM predictions WHERE is_demo=1"); c.commit(); print("Demo records removed."); return
    n = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 60
    model = ml.get_model(app.config["MODEL_PATH"], app.config["META_PATH"], True)
    X, _ = ml.synth(n, seed=7)
    r = np.random.default_rng(7)
    firms = ["Demo Telecom Ltd", "Demo Broadband Co", "Demo Mobile Services"]
    for i, row in X.iterrows():
        f = {k: (row[k].item() if hasattr(row[k], "item") else row[k]) for k in ml.FEATURES}
        res = ml.predict(model, f)
        when = datetime.now() - timedelta(days=int(r.integers(0, 30)), hours=int(r.integers(0, 24)))
        store.insert_prediction(c, {**f, **res, "company": firms[i % 3], "customer_ref": f"DEMO-{i+1:04d}", "user_email": None,
                                    "created_at": when.strftime(store.FMT)}, 0, demo=True)
    print(f"Added {n} demo records (flagged is_demo=1).")


if __name__ == "__main__":
    main()
