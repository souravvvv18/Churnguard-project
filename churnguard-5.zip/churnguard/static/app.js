(function () {
  var root = document.documentElement;
  var csrf = (document.querySelector('meta[name=csrf]') || {}).content;

  function updateThemeUI(t) {
    var sun = document.getElementById('theme-icon-sun');
    var moon = document.getElementById('theme-icon-moon');
    var txt = document.getElementById('theme-text');
    if (sun) sun.style.display = t === 'dark' ? 'inline-block' : 'none';
    if (moon) moon.style.display = t === 'light' ? 'inline-block' : 'none';
    if (txt) txt.textContent = t === 'dark' ? 'Light' : 'Dark';
  }

  function setTheme(t) {
    root.dataset.theme = t;
    document.cookie = 'cg_theme=' + t + ';path=/;max-age=31536000;SameSite=Lax';
    updateThemeUI(t);
    window.dispatchEvent(new Event('themechange'));
  }

  var tb = document.getElementById('theme-toggle');
  if (tb) {
    tb.addEventListener('click', function () {
      var nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      setTheme(nextTheme);
      fetch('/api/theme', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrf || ''
        },
        body: JSON.stringify({ theme: nextTheme })
      }).catch(function () {});
    });
  }

  // Mobile navigation drawer toggle
  var mb = document.getElementById('mobile-menu-btn');
  var md = document.getElementById('mobile-drawer');
  if (mb && md) {
    mb.addEventListener('click', function () {
      var open = md.classList.toggle('open');
      mb.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Prediction form: double-submit guard + total-charges estimate helper
  var pf = document.getElementById('predict-form');
  if (pf) {
    pf.addEventListener('submit', function () {
      var b = pf.querySelector('button[type=submit]');
      if (b) {
        b.disabled = true;
        b.innerHTML = '<span style="display:inline-block;animation:spin 1s linear infinite">⏳</span> Processing Inference…';
      }
    });

    var est = document.getElementById('estimate-total');
    if (est) {
      est.addEventListener('click', function () {
        var t = parseFloat(pf.tenure.value);
        var m = parseFloat(pf.monthly_charges.value);
        if (isNaN(t) || isNaN(m)) {
          if (!pf.tenure.value) pf.tenure.focus();
          else if (!pf.monthly_charges.value) pf.monthly_charges.focus();
          return;
        }
        pf.total_charges.value = (t * m).toFixed(2);
      });
    }
  }

  // Processing page: poll server status & render progressive audit stages
  var p = document.getElementById('proc');
  if (p) {
    var total = +p.dataset.total || 1;
    var remaining = +p.dataset.remaining || 0;
    var fails = 0;
    var stages = p.querySelectorAll('.stages li');
    var cd = document.getElementById('cd');
    var t0 = Date.now() - (total - remaining) * 1000;

    function tick() {
      var el = (Date.now() - t0) / 1000;
      var idx = Math.min(stages.length - 1, Math.floor((el / total) * stages.length));
      stages.forEach(function (s, i) {
        s.className = i < idx ? 'done' : (i === idx ? 'on' : '');
      });
      if (cd) cd.textContent = Math.max(0, Math.ceil(total - el));
    }

    function poll() {
      fetch(p.dataset.status, { credentials: 'same-origin' })
        .then(function (r) {
          if (!r.ok) throw 0;
          return r.json();
        })
        .then(function (d) {
          fails = 0;
          if (d.ready) {
            location.replace(p.dataset.result);
          } else {
            setTimeout(poll, 1000);
          }
        })
        .catch(function () {
          if (++fails > 5) {
            var perr = document.getElementById('perr');
            if (perr) perr.hidden = false;
          } else {
            setTimeout(poll, 1500);
          }
        });
    }

    var ticker = setInterval(tick, 200);
    tick();
    poll();
  }

  // Dashboard charts using bundled Chart.js
  var sd = document.getElementById('stats-data');
  if (sd && window.Chart) {
    var S = JSON.parse(sd.textContent);
    var charts = [];

    function css(name) {
      return getComputedStyle(root).getPropertyValue(name).trim();
    }

    function build() {
      charts.forEach(function (c) { c.destroy(); });
      charts = [];

      var col = {
        Low: css('--lo') || '#10b981',
        Medium: css('--med') || '#f59e0b',
        High: css('--hi') || '#f43f5e'
      };
      var txt = css('--muted') || '#94a3b8';
      var grid = css('--border') || '#1e293b';
      var surface = css('--surface') || '#111827';
      var accent = css('--accent') || '#6366f1';
      var accentCyan = css('--accent-cyan') || '#06b6d4';

      Chart.defaults.color = txt;
      Chart.defaults.font.family = 'Inter, system-ui, -apple-system, sans-serif';
      Chart.defaults.font.size = 12;

      var ax = {
        ticks: { color: txt },
        grid: { color: grid, drawBorder: false },
        border: { color: grid }
      };

      var mk = function (id, cfg) {
        var el = document.getElementById(id);
        if (el) charts.push(new Chart(el, cfg));
      };

      // 1. Doughnut: Risk Distribution
      mk('c-risk', {
        type: 'doughnut',
        data: {
          labels: ['Low Risk', 'Medium Risk', 'High Risk'],
          datasets: [{
            data: S.risk,
            backgroundColor: [col.Low, col.Medium, col.High],
            borderColor: surface,
            borderWidth: 3,
            hoverOffset: 4
          }]
        },
        options: {
          maintainAspectRatio: false,
          cutout: '66%',
          plugins: {
            legend: {
              position: 'bottom',
              labels: { boxWidth: 12, padding: 14 }
            }
          }
        }
      });

      // 2. Bar Chart: Probability Density Histogram
      mk('c-hist', {
        type: 'bar',
        data: {
          labels: S.hist.labels,
          datasets: [{
            label: 'Accounts',
            data: S.hist.counts,
            backgroundColor: accent,
            borderRadius: 6
          }]
        },
        options: {
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false }
          },
          scales: {
            x: ax,
            y: Object.assign({
              beginAtZero: true,
              title: { display: true, text: 'Customer Records', color: txt }
            }, ax, {
              ticks: { precision: 0, color: txt }
            })
          }
        }
      });

      // 3. Line/Bar Dual Axis: Risk Trend Over Time
      mk('c-trend', {
        data: {
          labels: S.trend.labels,
          datasets: [
            {
              type: 'line',
              label: 'Avg Churn Risk (%)',
              data: S.trend.avg,
              borderColor: accentCyan,
              backgroundColor: accentCyan,
              yAxisID: 'y',
              tension: 0.3,
              pointRadius: 4,
              borderWidth: 2.5
            },
            {
              type: 'bar',
              label: 'Predictions Evaluated',
              data: S.trend.count,
              backgroundColor: 'rgba(99, 102, 241, 0.35)',
              borderColor: accent,
              borderWidth: 1,
              borderRadius: 6,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          maintainAspectRatio: false,
          scales: {
            x: ax,
            y: Object.assign({}, ax, {
              min: 0,
              max: 100,
              title: { display: true, text: 'Mean Probability (%)', color: txt }
            }),
            y1: Object.assign({}, ax, {
              position: 'right',
              beginAtZero: true,
              grid: { drawOnChartArea: false },
              ticks: { precision: 0, color: txt },
              title: { display: true, text: 'Evaluations', color: txt }
            })
          }
        }
      });

      // 4. Stacked Bar: Risk by Contract
      mk('c-contract', {
        type: 'bar',
        data: {
          labels: S.by_contract.labels,
          datasets: ['Low', 'Medium', 'High'].map(function (k) {
            return {
              label: k + ' Risk',
              data: S.by_contract.series[k],
              backgroundColor: col[k],
              borderRadius: 4
            };
          })
        },
        options: {
          maintainAspectRatio: false,
          scales: {
            x: Object.assign({ stacked: true }, ax),
            y: Object.assign({
              stacked: true,
              beginAtZero: true,
              title: { display: true, text: 'Customer Accounts', color: txt }
            }, ax, {
              ticks: { precision: 0, color: txt }
            })
          }
        }
      });
    }

    build();
    window.addEventListener('themechange', build);
  }
})();
