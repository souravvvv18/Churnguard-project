import json, os, re, shutil, sqlite3, sys, tempfile, time, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pandas as pd
import app as appmod, db as store, ml

VALID = {"company": "Acme Telecom", "customer_ref": "C-100", "tenure": "3", "contract": "Month-to-month",
         "internet_service": "Fiber optic", "monthly_charges": "99.5", "total_charges": "290", "paperless_billing": "Yes",
         "payment_method": "Electronic check", "num_services": "2", "support_tickets": "5", "satisfaction": "1"}
SAFE = dict(VALID, company="Safe Co", customer_ref="C-200", tenure="60", contract="Two year", internet_service="DSL",
            monthly_charges="45", total_charges="2700", paperless_billing="No", payment_method="Credit card",
            num_services="6", support_tickets="0", satisfaction="5")


class Base(unittest.TestCase):
    delay = 0

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = {"DATABASE": f"{self.tmp}/c.db", "MODEL_PATH": f"{self.tmp}/m.joblib", "META_PATH": f"{self.tmp}/m.json",
                    "DEMO_DELAY_SECONDS": self.delay, "SECRET_KEY": "test", "TESTING": True}
        self.app = appmod.create_app(self.cfg)
        self.c = self.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def token(self, client=None, path="/login"):
        html = (client or self.c).get(path).get_data(as_text=True)
        return re.search(r'name="csrf" content="([^"]+)"', html).group(1)

    def login(self, client=None, email="sourav@example.com"):
        c = client or self.c
        return c.post("/login", data={"email": email, "password": "x", "csrf_token": self.token(c)})

    def post_predict(self, data, client=None):
        c = client or self.c
        return c.post("/predict", data=dict(data, csrf_token=self.token(c, "/predict")))

    def pid(self, resp):
        return resp.headers["Location"].rsplit("/", 1)[1]


class AuthTests(Base):
    def test_public_pages(self):
        for u in ("/", "/login", "/about"):
            self.assertEqual(self.c.get(u).status_code, 200, u)

    def test_protected_routes_redirect(self):
        for u in ("/dashboard", "/predict", "/records", "/settings", "/records/export.csv", "/records/CG-X"):
            r = self.c.get(u)
            self.assertEqual(r.status_code, 302, u)
            self.assertIn("/login", r.headers["Location"])

    def test_login_validation(self):
        t = self.token()
        self.assertEqual(self.c.post("/login", data={"email": "nope", "password": "x", "csrf_token": t}).status_code, 400)
        r = self.c.post("/login", data={"email": "a@b.co", "password": "", "csrf_token": t})
        self.assertEqual(r.status_code, 400); self.assertIn("Password cannot be empty", r.get_data(as_text=True))

    def test_login_logout_and_next(self):
        r = self.c.post("/login?next=/records", data={"email": "A@B.co", "password": "x", "csrf_token": self.token()})
        self.assertEqual(r.headers["Location"], "/records")
        self.assertEqual(self.c.get("/dashboard").status_code, 200)
        self.c.post("/logout", data={"csrf_token": self.token(path="/dashboard")})
        self.assertEqual(self.c.get("/dashboard").status_code, 302)

    def test_open_redirect_blocked(self):
        r = self.c.post("/login?next=//evil.com", data={"email": "a@b.co", "password": "x", "csrf_token": self.token()})
        self.assertEqual(r.headers["Location"], "/dashboard")

    def test_csrf_required(self):
        self.assertEqual(self.c.post("/login", data={"email": "a@b.co", "password": "x"}).status_code, 400)

    def test_cookie_flags(self):
        r = self.login()
        cookie = r.headers.get("Set-Cookie", "")
        self.assertIn("HttpOnly", cookie); self.assertIn("SameSite=Lax", cookie)


class PredictionTests(Base):
    def test_invalid_inputs_rejected_and_not_saved(self):
        self.login()
        for bad in ({"tenure": "-1"}, {"tenure": "abc"}, {"monthly_charges": "nan"}, {"company": ""}, {"contract": "Weekly"},
                    {"satisfaction": "9"}, {"total_charges": ""}, {"tenure": "0", "total_charges": "5000"}):
            r = self.post_predict(dict(VALID, **bad))
            self.assertEqual(r.status_code, 422, bad)
        r, _ = store.list_predictions(store.connect(self.cfg["DATABASE"]), {})
        self.assertEqual(r, [])

    def test_valid_prediction_saved_with_company(self):
        self.login()
        r = self.post_predict(VALID)
        self.assertEqual(r.status_code, 302)
        page = self.c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn("Acme Telecom", page); self.assertIn("C-100", page)
        row = store.get_prediction(store.connect(self.cfg["DATABASE"]), self.pid(r))
        self.assertEqual(row["company"], "Acme Telecom"); self.assertTrue(row["created_at"])

    def test_uses_real_model_not_random(self):
        self.login()
        a, b = self.post_predict(VALID), self.post_predict(SAFE)
        c = store.connect(self.cfg["DATABASE"])
        hi, lo = store.get_prediction(c, self.pid(a)), store.get_prediction(c, self.pid(b))
        model = ml.get_model(self.cfg["MODEL_PATH"], self.cfg["META_PATH"])
        for row, form in ((hi, VALID), (lo, SAFE)):
            f = {k: (float(form[k]) if k in ml.NUM else form[k]) for k in ml.FEATURES}
            expected = float(model.predict_proba(pd.DataFrame([f]))[0, 1])
            self.assertAlmostEqual(row["probability"], expected, places=9)
        self.assertGreater(hi["probability"], 0.6); self.assertLess(lo["probability"], 0.3)
        self.assertEqual((hi["risk"], lo["risk"]), ("High", "Low"))
        self.assertTrue(hi["factors"] and hi["actions"])

    def test_duplicate_submission_handled(self):
        self.login()
        a, b = self.post_predict(VALID), self.post_predict(VALID)
        self.assertEqual(self.pid(a), self.pid(b))
        _, total = store.list_predictions(store.connect(self.cfg["DATABASE"]), {})
        self.assertEqual(total, 1)

    def test_db_failure_does_not_discard_result(self):
        self.login()
        orig = store.insert_prediction
        store.insert_prediction = lambda *a, **k: (_ for _ in ()).throw(sqlite3.OperationalError("disk full"))
        try:
            r = self.post_predict(VALID)
        finally:
            store.insert_prediction = orig
        html = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 500); self.assertIn("NOT SAVED", html); self.assertIn("Acme Telecom", html)

    def test_persistence_after_restart(self):
        self.login()
        pid = self.pid(self.post_predict(VALID))
        c2 = appmod.create_app(self.cfg).test_client()
        self.login(c2)
        self.assertIn("Acme Telecom", c2.get(f"/records/{pid}").get_data(as_text=True))

    def test_unknown_record_404(self):
        self.login()
        self.assertEqual(self.c.get("/records/CG-NOPE").status_code, 404)


class DelayTests(Base):
    delay = 2

    def test_result_held_until_delay_elapsed(self):
        self.login()
        r = self.post_predict(VALID)
        pid = self.pid(r)
        self.assertIn('id="proc"', self.c.get(f"/records/{pid}").get_data(as_text=True))
        self.assertFalse(self.c.get(f"/api/records/{pid}/status").get_json()["ready"])
        self.assertEqual(self.c.get("/records/export.csv").get_data(as_text=True).count("\n"), 1)  # header only
        self.assertEqual(self.c.get(f"/records/{pid}/export.csv").status_code, 404)
        time.sleep(2.2)
        self.assertTrue(self.c.get(f"/api/records/{pid}/status").get_json()["ready"])
        self.assertIn("Churn probability", self.c.get(f"/records/{pid}").get_data(as_text=True))

    def test_delay_setting_and_production(self):
        self.login()
        self.c.post("/settings", data={"csrf_token": self.token(path="/settings"), "theme": "light", "display_name": "S", "demo_delay": "0", "github_repo_url": ""})
        r = self.post_predict(VALID)
        self.assertIn("Churn probability", self.c.get(r.headers["Location"]).get_data(as_text=True))
        prod = appmod.create_app(dict(self.cfg, PRODUCTION=True)).test_client()
        self.login(prod)
        r = self.post_predict(dict(VALID, company="ProdCo"), prod)
        self.assertIn("Churn probability", prod.get(r.headers["Location"]).get_data(as_text=True))


class DashboardTests(Base):
    def test_empty_states(self):
        self.login()
        self.assertIn("No prediction records", self.c.get("/dashboard").get_data(as_text=True))
        self.assertIn("No records found", self.c.get("/records").get_data(as_text=True))
        self.assertIn("No predictions yet", self.c.get("/").get_data(as_text=True))

    def test_filters_search_sort_pagination_export(self):
        self.login()
        for i in range(17):
            self.post_predict(dict(VALID, customer_ref=f"A{i}", company="Acme"))
        self.post_predict(dict(SAFE, company="=Evil Co"))
        d = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn("Prediction records", d); self.assertIn("stats-data", d)
        self.assertEqual(len(re.findall(r'href="/records/CG-', self.c.get("/records").get_data(as_text=True))), 15)
        self.assertIn("Page 2 of 2", self.c.get("/records?page=2").get_data(as_text=True))
        only = self.c.get("/records?company=Acme&risk=High").get_data(as_text=True)
        self.assertNotIn("<td>=Evil Co", only)
        self.assertIn("1 matching", self.c.get("/records?q=Evil").get_data(as_text=True))
        self.assertIn("1 matching", self.c.get("/records?risk=Low").get_data(as_text=True))
        self.assertIn("18 matching", self.c.get("/records?date_from=2000-01-01").get_data(as_text=True))
        self.assertIn("0 matching", self.c.get("/records?date_to=2000-01-01").get_data(as_text=True))
        self.assertEqual(self.c.get("/records?sort=DROP%20TABLE&dir=x").status_code, 200)
        self.assertEqual(self.c.get("/records?date_from=bad").status_code, 200)
        csv_ = self.c.get("/records/export.csv?company=Acme")
        self.assertEqual(csv_.mimetype, "text/csv"); self.assertEqual(csv_.get_data(as_text=True).count("\n"), 18)
        self.assertIn("'=Evil Co", self.c.get("/records/export.csv").get_data(as_text=True))
        s = store.stats(store.connect(self.cfg["DATABASE"]), {})
        self.assertEqual((s["records"], s["customers"], s["no_id_records"]), (18, 18, 0))
        self.assertEqual(sum(s["hist"]["counts"]), 18); self.assertEqual(sum(s["risk"]), 18)

    def test_demo_seed_flagged(self):
        self.login()
        import subprocess
        env = dict(os.environ)
        c = store.connect(self.cfg["DATABASE"])
        model = ml.get_model(self.cfg["MODEL_PATH"], self.cfg["META_PATH"])
        X, _ = ml.synth(5, 1)
        for i, row in X.iterrows():
            f = {k: (row[k].item() if hasattr(row[k], "item") else row[k]) for k in ml.FEATURES}
            store.insert_prediction(c, {**f, **ml.predict(model, f), "company": "Demo Co", "customer_ref": f"D{i}", "user_email": None}, 0, demo=True)
        self.assertIn("5 matching", self.c.get("/records?source=demo").get_data(as_text=True))
        self.assertIn("0 matching", self.c.get("/records?source=real").get_data(as_text=True))


class SettingsTests(Base):
    def test_theme_persists(self):
        self.login()
        self.assertIn('data-theme="light"', self.c.get("/dashboard").get_data(as_text=True))
        r = self.c.post("/api/theme", json={"theme": "dark"}, headers={"X-CSRF-Token": self.token(path="/dashboard")})
        self.assertEqual(r.status_code, 200)
        self.assertIn('data-theme="dark"', self.c.get("/records").get_data(as_text=True))
        fresh = self.app.test_client(); self.login(fresh)  # new browser: preference comes from DB
        self.assertIn('data-theme="dark"', fresh.get("/settings").get_data(as_text=True))
        self.assertEqual(self.c.post("/api/theme", json={"theme": "pink"}, headers={"X-CSRF-Token": self.token(path="/dashboard")}).status_code, 400)

    def test_settings_validation_and_save(self):
        self.login()
        t = self.token(path="/settings")
        bad = self.c.post("/settings", data={"csrf_token": t, "theme": "dark", "display_name": "S", "demo_delay": "99", "github_repo_url": "http://evil"})
        html = bad.get_data(as_text=True)
        self.assertIn("0 to 60", html); self.assertIn("https://github.com/", html)
        ok = self.c.post("/settings", data={"csrf_token": t, "theme": "dark", "display_name": "Sourav K", "demo_delay": "5", "github_repo_url": "https://github.com/souravvvv18/demo-repo"}, follow_redirects=True)
        page = ok.get_data(as_text=True)
        self.assertIn("Settings saved", page); self.assertIn("Sourav K", page); self.assertIn("souravvvv18/demo-repo/issues/new", page)

    def test_repo_unconfigured_shows_no_fake_link(self):
        self.login()
        page = self.c.get("/settings").get_data(as_text=True)
        self.assertIn("Not configured yet", page); self.assertIn('aria-disabled="true"', page)
        self.assertNotIn("/issues/new", page)


class ModelTests(Base):
    def test_missing_model_without_autotrain(self):
        app = appmod.create_app(dict(self.cfg, AUTO_TRAIN=False, MODEL_PATH=f"{self.tmp}/none.joblib"))
        c = app.test_client(); self.login(c)
        r = self.post_predict(VALID, c)
        self.assertEqual(r.status_code, 503); self.assertIn("Model unavailable", r.get_data(as_text=True))

    def test_corrupt_model(self):
        open(self.cfg["MODEL_PATH"], "w").write("garbage")
        self.login()
        r = self.post_predict(VALID)
        self.assertEqual(r.status_code, 503); self.assertIn("could not be loaded", r.get_data(as_text=True))

    def test_autotrain_creates_model(self):
        self.login(); self.post_predict(VALID)
        self.assertTrue(os.path.exists(self.cfg["MODEL_PATH"]))
        self.assertEqual(json.load(open(self.cfg["META_PATH"]))["data_source"], "synthetic")


class MigrationTests(unittest.TestCase):
    def test_legacy_v1_rows_preserved(self):
        tmp = tempfile.mkdtemp(); path = f"{tmp}/old.db"
        c = sqlite3.connect(path)
        c.execute("""CREATE TABLE predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, tenure INT, monthly REAL,
                     contract INT, calls INT, prob REAL, result TEXT, reason TEXT, created TEXT)""")
        c.execute("INSERT INTO predictions(name,tenure,monthly,contract,calls,prob,result,reason,created) VALUES('Amit',2,95,0,6,0.9,'Will Churn','x','2026-10-01 10:00')")
        c.execute("INSERT INTO predictions(name,tenure,monthly,contract,calls,prob,result,reason,created) VALUES('RealUser',9,50,2,0,0.1,'Safe','y','2026-10-02 11:30')")
        c.commit(); c.close()
        app = appmod.create_app({"DATABASE": path, "MODEL_PATH": f"{tmp}/m.joblib", "META_PATH": f"{tmp}/m.json", "SECRET_KEY": "k"})
        c = store.connect(path)
        rows, total = store.list_predictions(c, {})
        self.assertEqual(total, 2)
        self.assertEqual(c.execute("PRAGMA user_version").fetchone()[0], len(store.MIGRATIONS))
        appmod.create_app({"DATABASE": path, "MODEL_PATH": f"{tmp}/m.joblib", "META_PATH": f"{tmp}/m.json", "SECRET_KEY": "k"})  # idempotent
        self.assertEqual(store.list_predictions(store.connect(path), {})[1], 2)
        shutil.rmtree(tmp, ignore_errors=True)


class FeedbackTests(Base):
    def test_feedback_page_public(self):
        r = self.c.get("/feedback")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Feature Request & Feedback", r.get_data(as_text=True))

    def test_feedback_validation(self):
        t = self.token(path="/feedback")
        bad = self.c.post("/feedback", data={"csrf_token": t, "title": "", "category": "InvalidCat", "description": "short"})
        self.assertEqual(bad.status_code, 422)
        html = bad.get_data(as_text=True)
        self.assertIn("Title is required", html)
        self.assertIn("Select a valid category", html)
        self.assertIn("at least 10 characters", html)

    def test_feedback_submission_and_storage(self):
        self.login()
        t = self.token(path="/feedback")
        r = self.c.post("/feedback", data={
            "csrf_token": t,
            "title": "Add CSV export for high-risk cohorts",
            "category": "Feature request",
            "description": "It would be useful to filter and export high risk customer records directly."
        }, follow_redirects=True)
        self.assertEqual(r.status_code, 200)
        html = r.get_data(as_text=True)
        self.assertIn("saved locally to SQLite", html)
        self.assertIn("Add CSV export for high-risk cohorts", html)

        c = store.connect(self.cfg["DATABASE"])
        items = store.list_feedback(c)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["title"], "Add CSV export for high-risk cohorts")
        self.assertEqual(items[0]["category"], "Feature request")
        self.assertTrue(items[0]["public_id"].startswith("FB-"))


if __name__ == "__main__":
    unittest.main(verbosity=2)

