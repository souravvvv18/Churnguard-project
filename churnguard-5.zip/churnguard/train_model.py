"""Train (or retrain) the churn model. To use real data, replace ml.synth() with your own DataFrame
that has the columns listed in ml.FEATURES plus a 0/1 churn label."""
from config import Config
import ml

if __name__ == "__main__":
    ml.train(Config.MODEL_PATH, Config.META_PATH)
    print("Model saved:", Config.MODEL_PATH)
    print(open(Config.META_PATH).read())
