import math
import ml

NUMERIC = {  # name: (label, type, min, max)
    "tenure": ("Tenure", int, 0, 120),
    "monthly_charges": ("Monthly charges", float, 0, 10_000),
    "total_charges": ("Total charges", float, 0, 10_000_000),
    "num_services": ("Number of services", int, 1, 12),
    "support_tickets": ("Support tickets", int, 0, 100),
    "satisfaction": ("Satisfaction", int, 1, 5),
}
DEFAULTS = {"company": "", "customer_ref": "", "tenure": "", "monthly_charges": "", "total_charges": "",
            "contract": "Month-to-month", "paperless_billing": "Yes", "payment_method": "Electronic check",
            "internet_service": "Fiber optic", "num_services": "3", "support_tickets": "0", "satisfaction": "3"}


def validate(form):
    clean, err = {}, {}
    company = (form.get("company") or "").strip()
    if not company:
        err["company"] = "Company name is required."
    elif len(company) > 80:
        err["company"] = "Company name must be 80 characters or fewer."
    clean["company"] = company
    ref = (form.get("customer_ref") or "").strip()
    if len(ref) > 40:
        err["customer_ref"] = "Customer ID must be 40 characters or fewer."
    clean["customer_ref"] = ref or None
    for k, (label, typ, lo, hi) in NUMERIC.items():
        raw = (form.get(k) or "").strip()
        if not raw:
            err[k] = f"{label} is required."
            continue
        try:
            v = typ(raw)
        except ValueError:
            err[k] = f"{label} must be a {'whole number' if typ is int else 'number'}."
            continue
        if not math.isfinite(v) or not lo <= v <= hi:
            err[k] = f"{label} must be between {lo} and {hi:,}."
            continue
        clean[k] = v
    for k, opts in ml.CHOICES.items():
        v = form.get(k, "")
        if v not in opts:
            err[k] = "Select a valid option."
        clean[k] = v
    if not err and clean["tenure"] == 0 and clean["total_charges"] > clean["monthly_charges"] * 2:
        err["total_charges"] = "Total charges look inconsistent with 0 months of tenure."
    return clean, err


FEEDBACK_CATEGORIES = [
    "Feature request",
    "Model improvement",
    "UI / Usability",
    "Data integration",
    "Bug report"
]


def validate_feedback(form):
    clean, err = {}, {}
    title = (form.get("title") or "").strip()
    if not title:
        err["title"] = "Title is required."
    elif len(title) > 120:
        err["title"] = "Title must be 120 characters or fewer."
    clean["title"] = title

    cat = (form.get("category") or "").strip()
    if cat not in FEEDBACK_CATEGORIES:
        err["category"] = "Select a valid category."
    clean["category"] = cat

    desc = (form.get("description") or "").strip()
    if not desc:
        err["description"] = "Description is required."
    elif len(desc) < 10:
        err["description"] = "Please provide at least 10 characters describing your request."
    elif len(desc) > 3000:
        err["description"] = "Description must be 3,000 characters or fewer."
    clean["description"] = desc

    return clean, err

