import csv, io, logging, math, re, sqlite3
from datetime import date, timedelta
from flask import (Blueprint, Response, abort, current_app as app, flash, jsonify, make_response,
                   redirect, render_template, request, session, url_for)
import auth, db as store, ml, validation

bp = Blueprint("main", __name__)
log = logging.getLogger("churnguard")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
REPO_RE = re.compile(r"^https://github\.com/[\w.-]+/[\w.-]+/?$")
CSV_COLS = ["public_id", "created_at", "company", "customer_ref", "tenure", "contract", "monthly_charges", "total_charges",
            "payment_method", "paperless_billing", "internet_service", "num_services", "support_tickets", "satisfaction",
            "probability", "risk", "is_demo"]


def prefs():
    u = auth.current_user()
    return store.get_prefs(store.get_db(), u) if u else {}


def repo_url():
    return store.get_setting(store.get_db(), "github_repo_url") or app.config["GITHUB_REPO_URL"]


@bp.app_context_processor
def inject():
    u, p = auth.current_user(), prefs()
    theme = request.cookies.get("cg_theme") or p.get("theme") or "light"
    return {"csrf_token": auth.csrf_token(), "user": u, "theme": theme if theme in ("light", "dark") else "light",
            "display_name": p.get("display_name") or (u.split("@")[0] if u else ""), "repo_url": repo_url(),
            "version": app.config["VERSION"], "profile_url": app.config["GITHUB_PROFILE_URL"],
            "contributors": app.config["CONTRIBUTORS"]}


@bp.app_template_global()
def url_with(endpoint, **kw):
    """Current query string with some values overridden (empty values dropped)."""
    a = {**request.args.to_dict(), **kw}
    return url_for(endpoint, **{k: x for k, x in a.items() if x not in ("", None)})


def demo_delay():
    if app.config["PRODUCTION"]:
        return 0
    try:
        return max(0, min(60, int(prefs().get("demo_delay", app.config["DEMO_DELAY_SECONDS"]))))
    except ValueError:
        return app.config["DEMO_DELAY_SECONDS"]


def get_filters():
    f = {k: request.args.get(k, "").strip()[:80] for k in ("q", "company", "risk", "contract", "source", "date_from", "date_to")}
    for k in ("date_from", "date_to"):
        if not DATE_RE.match(f[k]):
            f[k] = ""
    if f["risk"] not in ml.RISKS:
        f["risk"] = ""
    if f["contract"] not in ml.CHOICES["contract"]:
        f["contract"] = ""
    return f


def csv_response(rows, name):
    def safe(v):  # neutralise spreadsheet formula injection
        s = "" if v is None else str(v)
        return "'" + s if s[:1] in "=+-@\t\r" else s
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(CSV_COLS)
    for r in rows:
        w.writerow([safe(r.get(c)) for c in CSV_COLS])
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={name}"})


# ---------- public ----------
@bp.route("/")
def home():
    s = store.stats(store.get_db(), {})
    return render_template("home.html", s=s, meta=ml.read_meta(app.config["META_PATH"]))


@bp.route("/about")
def about():
    return render_template("about.html", meta=ml.read_meta(app.config["META_PATH"]))


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        err = auth.check_credentials(email, request.form.get("password", ""))
        if err:
            return render_template("login.html", error=err, email=email), 400
        nxt = request.args.get("next", "")
        auth.login_user(email)
        return redirect(nxt if auth.safe_next(nxt) else url_for("main.dashboard"))
    return render_template("login.html", error=None, email="")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been signed out.")
    return redirect(url_for("main.home"))


# ---------- predictions ----------
@bp.route("/predict", methods=["GET", "POST"])
@auth.login_required
def predict():
    vals, errors, model_error = dict(validation.DEFAULTS), {}, None
    preset = request.args.get("preset", "").lower()
    if request.method == "GET" and preset:
        presets = {
            "high": {
                "company": "Apex Global Logistics", "customer_ref": "C-HIGH-01", "tenure": "3",
                "contract": "Month-to-month", "internet_service": "Fiber optic",
                "monthly_charges": "104.50", "total_charges": "313.50", "paperless_billing": "Yes",
                "payment_method": "Electronic check", "num_services": "2", "support_tickets": "4", "satisfaction": "1"
            },
            "low": {
                "company": "Zenith Enterprises", "customer_ref": "C-LOYAL-99", "tenure": "58",
                "contract": "Two year", "internet_service": "DSL",
                "monthly_charges": "48.20", "total_charges": "2795.60", "paperless_billing": "No",
                "payment_method": "Credit card", "num_services": "6", "support_tickets": "0", "satisfaction": "5"
            },
            "medium": {
                "company": "Vanguard Media", "customer_ref": "C-MID-42", "tenure": "18",
                "contract": "One year", "internet_service": "Fiber optic",
                "monthly_charges": "74.00", "total_charges": "1332.00", "paperless_billing": "Yes",
                "payment_method": "Bank transfer", "num_services": "4", "support_tickets": "2", "satisfaction": "3"
            }
        }
        if preset in presets:
            vals.update(presets[preset])

    if request.method == "POST":
        vals = request.form.to_dict()
        clean, errors = validation.validate(request.form)
        if not errors:
            try:
                model = ml.get_model(app.config["MODEL_PATH"], app.config["META_PATH"], app.config["AUTO_TRAIN"])
            except ml.ModelUnavailable as e:
                return render_template("predict.html", vals=vals, errors={}, model_error=str(e), choices=ml.CHOICES), 503
            rec = {**clean, **ml.predict(model, clean), "user_email": auth.current_user()}
            try:
                pid, dup = store.insert_prediction(store.get_db(), rec, demo_delay())
            except sqlite3.Error:
                log.exception("Could not save prediction")
                flash("The prediction was calculated but could NOT be saved to the database.", "error")
                return render_template("result.html", r={**rec, "public_id": "UNSAVED", "created_at": store.now()},
                                       unsaved=True, meta=ml.read_meta(app.config["META_PATH"]), choices=ml.CHOICES), 500
            if dup:
                flash("An identical prediction was submitted a moment ago. Showing the existing record.")
            return redirect(url_for("main.record", pid=pid))
        flash("Please correct the highlighted fields.", "error")
    return render_template("predict.html", vals=vals, errors=errors, model_error=model_error, choices=ml.CHOICES), (422 if errors else 200)



@bp.route("/records/<pid>")
@auth.login_required
def record(pid):
    r = store.get_prediction(store.get_db(), pid) or abort(404)
    wait = store.seconds_until(r["released_at"])
    if wait > 0:
        total = max(1, round((store.datetime.strptime(r["released_at"], store.FMT) - store.datetime.strptime(r["created_at"], store.FMT)).total_seconds()))
        return render_template("processing.html", pid=pid, company=r["company"], total=total, remaining=math.ceil(wait))
    return render_template("result.html", r=r, unsaved=False, meta=ml.read_meta(app.config["META_PATH"]))


@bp.route("/api/records/<pid>/status")
@auth.login_required
def status(pid):
    r = store.get_prediction(store.get_db(), pid) or abort(404)
    wait = store.seconds_until(r["released_at"])
    return jsonify(ready=wait <= 0, remaining=math.ceil(wait))


@bp.route("/records/<pid>/export.csv")
@auth.login_required
def record_csv(pid):
    r = store.get_prediction(store.get_db(), pid) or abort(404)
    if store.seconds_until(r["released_at"]) > 0:
        abort(404)
    return csv_response([r], f"churnguard_{pid}.csv")


@bp.route("/records")
@auth.login_required
def records():
    f, c = get_filters(), store.get_db()
    sort, direction = request.args.get("sort", "created_at"), request.args.get("dir", "desc")
    page = max(1, request.args.get("page", 1, type=int) or 1)
    size = app.config["PAGE_SIZE"]
    rows, total = store.list_predictions(c, f, sort, direction, page, size)
    pages = max(1, math.ceil(total / size))
    if page > pages:
        return redirect(url_for("main.records", **{**request.args.to_dict(), "page": pages}))
    return render_template("records.html", rows=rows, total=total, page=page, pages=pages, f=f, sort=sort, dir=direction,
                           companies=store.companies(c), choices=ml.CHOICES)


@bp.route("/records/export.csv")
@auth.login_required
def records_csv():
    rows, _ = store.list_predictions(store.get_db(), get_filters(), request.args.get("sort", "created_at"),
                                     request.args.get("dir", "desc"), 1, 0)
    return csv_response(rows, "churnguard_records.csv")


@bp.route("/dashboard")
@auth.login_required
def dashboard():
    f, c = get_filters(), store.get_db()
    s = store.stats(c, f)
    recent, _ = store.list_predictions(c, f, "created_at", "desc", 1, 8)
    today = date.today()
    presets = {"Last 7 days": (today - timedelta(days=6)).isoformat(), "Last 30 days": (today - timedelta(days=29)).isoformat(), "All time": ""}
    return render_template("dashboard.html", s=s, recent=recent, f=f, companies=store.companies(c), choices=ml.CHOICES,
                           presets=presets, today=today.isoformat(), sort="created_at", dir="desc")


# ---------- settings ----------
def themed(resp, theme):
    resp.set_cookie("cg_theme", theme, max_age=31536000, samesite="Lax", secure=app.config["PRODUCTION"])
    return resp


@bp.route("/settings", methods=["GET", "POST"])
@auth.login_required
def settings():
    c, u = store.get_db(), auth.current_user()
    errors = {}
    if request.method == "POST":
        theme = request.form.get("theme", "light")
        name = request.form.get("display_name", "").strip()
        delay = request.form.get("demo_delay", "").strip()
        repo = request.form.get("github_repo_url", "").strip()
        if theme not in ("light", "dark"):
            errors["theme"] = "Choose light or dark."
        if len(name) > 60:
            errors["display_name"] = "Display name must be 60 characters or fewer."
        if not app.config["PRODUCTION"] and not (delay.isdigit() and 0 <= int(delay) <= 60):
            errors["demo_delay"] = "Enter a whole number from 0 to 60."
        if repo and not REPO_RE.match(repo):
            errors["github_repo_url"] = "Use a URL like https://github.com/<user>/<repo>."
        if not errors:
            store.set_pref(c, u, "theme", theme)
            store.set_pref(c, u, "display_name", name)
            if not app.config["PRODUCTION"]:
                store.set_pref(c, u, "demo_delay", delay)
            store.set_setting(c, "github_repo_url", repo.rstrip("/"))
            flash("Settings saved.")
            return themed(redirect(url_for("main.settings")), theme)
        flash("Settings were not saved. Please fix the errors.", "error")
    p = prefs()
    return render_template("settings.html", errors=errors, p=p, delay=demo_delay(), meta=ml.read_meta(app.config["META_PATH"]),
                           db_path=app.config["DATABASE"], env="production" if app.config["PRODUCTION"] else "development",
                           saved_repo=store.get_setting(c, "github_repo_url"))


@bp.route("/api/theme", methods=["POST"])
def api_theme():
    theme = (request.get_json(silent=True) or {}).get("theme")
    if theme not in ("light", "dark"):
        abort(400)
    if auth.current_user():
        store.set_pref(store.get_db(), auth.current_user(), "theme", theme)
    return themed(make_response(jsonify(theme=theme)), theme)


# ---------- feature requests & feedback ----------
@bp.route("/feedback", methods=["GET", "POST"])
def feedback():
    c = store.get_db()
    errors = {}
    vals = {"title": "", "category": "Feature request", "description": ""}
    if request.method == "POST":
        vals = {
            "title": request.form.get("title", "").strip(),
            "category": request.form.get("category", "").strip(),
            "description": request.form.get("description", "").strip(),
        }
        clean, errors = validation.validate_feedback(request.form)
        if not errors:
            rec = {
                **clean,
                "user_email": auth.current_user(),
            }
            try:
                fid = store.insert_feedback(c, rec)
                flash(f"Thank you! Your feedback has been saved locally to SQLite (ID: {fid}).", "success")
                return redirect(url_for("main.feedback"))
            except sqlite3.Error:
                log.exception("Could not save feedback")
                flash("A database error occurred while saving feedback. Please try again.", "error")
        else:
            flash("Please correct the errors in your submission.", "error")

    items = store.list_feedback(c, limit=30)
    return render_template(
        "feedback.html",
        vals=vals,
        errors=errors,
        categories=validation.FEEDBACK_CATEGORIES,
        items=items,
    ), (422 if errors else 200)

