import express from 'express';
import http from 'http';
import { spawn } from 'child_process';
import path from 'path';

const app = express();
const PORT = 3000;
const FLASK_PORT = 5000;
const rootDir = process.cwd();
const churnguardDir = path.resolve(rootDir, 'churnguard');

console.log(`[ChurnGuard Bridge] Launching Python Flask backend in ${churnguardDir} ...`);

const flask = spawn('python3', ['app.py'], {
  cwd: churnguardDir,
  env: {
    ...process.env,
    PORT: String(FLASK_PORT),
    HOST: '127.0.0.1',
    PYTHONUNBUFFERED: '1',
  },
  stdio: 'inherit',
});

flask.on('error', (err) => {
  console.error('[ChurnGuard Bridge] Failed to spawn Flask process:', err);
});

flask.on('close', (code) => {
  console.log(`[ChurnGuard Bridge] Flask process exited with code ${code}`);
});

process.on('SIGINT', () => {
  flask.kill();
  process.exit();
});

process.on('SIGTERM', () => {
  flask.kill();
  process.exit();
});

// Reverse proxy from port 3000 to Flask on 127.0.0.1:5000
app.use((req, res) => {
  const options: http.RequestOptions = {
    hostname: '127.0.0.1',
    port: FLASK_PORT,
    path: req.originalUrl || req.url,
    method: req.method,
    headers: {
      ...req.headers,
      host: `127.0.0.1:${FLASK_PORT}`,
      'x-forwarded-for': req.socket.remoteAddress,
      'x-forwarded-proto': 'http',
      'x-forwarded-host': req.headers.host || `localhost:${PORT}`,
    },
  };

  const proxyReq = http.request(options, (proxyRes) => {
    res.writeHead(proxyRes.statusCode || 200, proxyRes.headers);
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (err: NodeJS.ErrnoException) => {
    if (err.code === 'ECONNREFUSED' || err.code === 'ECONNRESET') {
      res.status(503).send(`
        <!doctype html>
        <html lang="en" style="background:#0b0f19;color:#f8fafc;font-family:sans-serif">
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <meta http-equiv="refresh" content="1">
            <title>Starting ChurnGuard...</title>
          </head>
          <body style="display:flex;align-items:center;justify-content:center;height:90vh;margin:0">
            <div style="text-align:center;max-width:440px;padding:30px;background:#111827;border:1px solid #1e293b;border-radius:12px;box-shadow:0 10px 25px rgba(0,0,0,0.5)">
              <div style="font-size:2.5rem;margin-bottom:12px;animation:pulse 1.5s infinite">🛡️</div>
              <h2 style="margin:0 0 8px;font-size:1.4rem">Initializing ChurnGuard Server</h2>
              <p style="color:#94a3b8;font-size:0.9rem;line-height:1.5;margin:0 0 16px">
                Starting Python Flask and loading the scikit-learn machine learning pipeline...
              </p>
              <div style="height:6px;width:100%;background:#1e293b;border-radius:99px;overflow:hidden;position:relative">
                <div style="position:absolute;width:40%;height:100%;background:#6366f1;border-radius:99px;animation:move 1.2s infinite ease-in-out"></div>
              </div>
            </div>
            <style>
              @keyframes move { 0% { left: -40%; } 100% { left: 100%; } }
              @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
            </style>
          </body>
        </html>
      `);
    } else {
      console.error('[ChurnGuard Bridge] Proxy error:', err);
      res.status(502).send('Bad Gateway');
    }
  });

  req.pipe(proxyReq);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[ChurnGuard Bridge] Server listening on http://0.0.0.0:${PORT}`);
});
